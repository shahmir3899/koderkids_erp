from datetime import datetime
from itertools import count
from rest_framework import viewsets
from .models import Student
from .serializers import StudentSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import Fee, School
from .serializers import FeeSerializer
from decimal import Decimal  # Import Decimal
from django.utils.timezone import now
from django.db.models import Sum, Count
from .serializers import SchoolSerializer



class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer



@api_view(['GET'])
def get_students(request):
    students = Student.objects.all()

    if not students.exists():  # Debug: Check if records exist
        return Response({"message": "No students found"}, status=200)

    serializer = StudentSerializer(students, many=True)
    return Response(serializer.data)
@api_view(['GET'])
def students_per_school(request):
    data = Student.objects.values('school').annotate(total_students=Count('id'))
    return Response(list(data))

@api_view(['POST'])
def update_fees(request):
    """Updates status and paid_amount in the Fee table"""
    
    fees_data = request.data.get("fees", [])

    if not fees_data:
        print("❌ No fee data received in request")  # Debugging
        return Response({"error": "No fee data received"}, status=400)

    print(f"✅ Received {len(fees_data)} fee updates")  # Debugging

    for fee_data in fees_data:
        try:
            print(f"🔄 Processing fee ID: {fee_data['id']}")  # Debugging

            fee = Fee.objects.get(id=fee_data["id"])
            fee.paid_amount = Decimal(str(fee_data.get("paid_amount", 0)))  # Convert to Decimal
            fee.balance_due = fee.total_fee - fee.paid_amount  # Recalculate balance due
            fee.status = fee_data.get("status", "Pending")  # Default status if missing
            fee.save()

            print(f"✅ Updated Fee ID: {fee.id}, Paid: {fee.paid_amount}, Status: {fee.status}")  # Debugging

        except Fee.DoesNotExist:
            print(f"❌ Fee ID {fee_data['id']} not found in database")  # Debugging
            continue  # Skip if fee record is missing

        except Exception as e:
            print(f"❌ Error updating fee ID {fee_data['id']}: {e}")  # Debugging
            return Response({"error": str(e)}, status=500)

    return Response({"message": "Fee records updated successfully!"})
@api_view(['GET', 'POST'])
def schools_list(request):
    if request.method == 'GET':
        schools = School.objects.all()
        serializer = SchoolSerializer(schools, many=True)
        return Response(serializer.data)
    
    if request.method == 'POST':
        serializer = SchoolSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)

@api_view(['GET'])
def get_fees(request):
    fees = Fee.objects.all()
    fee_list = []

    for fee in fees:
        fee_list.append({
            "id": fee.id,
            "student_name": fee.student_name,
            "school": fee.school,
            "student_class": fee.student_class,
            "monthly_fee": fee.monthly_fee,
            "month": fee.month,
            "total_fee": fee.total_fee,
            "paid_amount": fee.paid_amount,
            "balance_due": fee.balance_due,
            "payment_date": fee.payment_date,
            "status": fee.status,
            "student_id": fee.student_id
        })

    return Response(fee_list)
@api_view(['GET'])
def students_per_school(request):
    data = Student.objects.values('school').annotate(total_students=Count('id'))
    return Response(data)
@api_view(['GET'])
def fee_received_per_month(request):
    data = Fee.objects.values('school', 'month').annotate(total_fee=Sum('paid_amount'))
    return Response(data)
@api_view(['GET'])
def new_registrations(request):
    last_month = now().month  # Get the current month
    current_year = now().year

    students = Student.objects.filter(
        date_of_registration__month=last_month,
        date_of_registration__year=current_year
    ).values('id', 'name', 'school', 'date_of_registration')

    return Response(students)
@api_view(['POST'])
def create_new_month_fees(request):
    """Creates fee records for all active students for the next month"""

    # Step 1: Get all Active Students
    active_students = Student.objects.filter(status="Active")
    
    print(f"Found {active_students.count()} active students")  # Debugging line
    
    if not active_students.exists():
        return Response({"message": "No active students found. Cannot create fee records."}, status=400)

    # Step 2: Determine the next month
    latest_fee = Fee.objects.order_by('-id').first()
    if latest_fee:
        prev_month_str = latest_fee.month  
        prev_month_date = datetime.strptime(prev_month_str, "%b-%Y")
        next_month = prev_month_date.month + 1
        next_year = prev_month_date.year
        if next_month > 12:
            next_month = 1
            next_year += 1
        next_month_str = datetime(next_year, next_month, 1).strftime("%b-%Y")
    else:
        next_month_str = "Dec-2024"

    # Step 3: Create Fee Records
    new_fees = []
    for student in active_students:
        last_fee_entry = Fee.objects.filter(student_id=student.id).order_by('-id').first()
        previous_balance = last_fee_entry.balance_due if last_fee_entry else 0
        
        fee = Fee(
            student_id=student.id,
            student_name=student.name,
            school=student.school,
            student_class=student.student_class,
            monthly_fee=student.monthly_fee,
            month=next_month_str,
            total_fee=previous_balance + student.monthly_fee,
            paid_amount=0.00,
            balance_due=previous_balance + student.monthly_fee,
            payment_date=f"{datetime.strptime(next_month_str, '%b-%Y').year}-{datetime.strptime(next_month_str, '%b-%Y').month:02d}-15",  # Fix here
            status="Pending"
        )
        print(f"Creating Fee for {student.name} - {next_month_str}")  # Debugging line
        new_fees.append(fee)
    
    # Step 4: Bulk Insert
    Fee.objects.bulk_create(new_fees)
    
    print(f"Inserted {len(new_fees)} fee records into the database")  # Debugging line
    
    return Response({"message": f"Fee records created for {next_month_str}!"})