from django.urls import path
from rest_framework.routers import DefaultRouter
from django.shortcuts import render
from .views import (
    StudentViewSet, get_fees, get_students, 
    create_new_month_fees, update_fees, 
    students_per_school, fee_received_per_month, 
    new_registrations, schools_list
)

# ✅ Register ViewSet-based routes
router = DefaultRouter()
router.register(r'students', StudentViewSet)

def home(request):
    return render(request, 'index.html')

urlpatterns = [
    path('', include(router.urls)),  # ✅ Default Router URLs
    path('fees/', get_fees, name='get_fees'),
    path('students/', get_students, name='get_students'),
    path('fees/create/', create_new_month_fees, name='create_new_month_fees'),
    path('fees/update/', update_fees, name='update_fees'),
    path('students-per-school/', students_per_school, name='students_per_school'),
    path('fee-per-month/', fee_received_per_month, name='fee_received_per_month'),
    path('new-registrations/', new_registrations, name='new_registrations'),
    path('schools/', schools_list, name="schools_list"),  # ✅ Ensure only one schools route

    # ❌ REMOVE THIS LINE TO AVOID RECURSION
    # path('api/', include('students.urls')),
]
