from rest_framework import serializers
from .models import Student, Fee, School

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = '__all__'

class FeeSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.name', read_only=True)  # Get student name

    class Meta:
        model = Fee
        fields = ['id', 'student', 'student_name', 'month', 'total_fee', 'paid_amount', 'balance_due', 'payment_date', 'status']
class SchoolSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = '__all__'