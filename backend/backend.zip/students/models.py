from django.db import models

class Student(models.Model):
    STATUS_CHOICES = [
        ('Active', 'Active'),
        ('Pass Out', 'Pass Out'),
        ('Left', 'Left'),
        ('Suspended', 'Suspended'),
        ('Expelled', 'Expelled'),
    ]

    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]
    date_of_registration = models.DateField(default="1990-01-01")
    reg_num = models.CharField(max_length=50, unique=True, default="Unknown")
    name = models.CharField(max_length=100, default="Unknown")
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, default='Male')
    school = models.CharField(max_length=200, default="Unknown")
    monthly_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    date_of_birth = models.DateField(default="1990-01-01")
    student_class = models.CharField(max_length=10, default="PlayGroup")
    phone = models.CharField(max_length=20, blank=True, null=True, default="Unknown")
    address = models.TextField(blank=True, null=True, default="Unknown")    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Active')
class School(models.Model):
    name = models.CharField(max_length=255, unique=True)
    location = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.name
    
class Fee(models.Model):
    student_id = models.BigIntegerField()  # Keep student ID
    student_name = models.CharField(max_length=100, default="Unknown")  # New Field
    school = models.CharField(max_length=200, default="Unknown")  # New Field
    student_class = models.CharField(max_length=50, default="Unknown")  # New Field
    monthly_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # New Field

    month = models.CharField(max_length=10)  # E.g., "Feb-2025"
    total_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    paid_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    balance_due = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    payment_date = models.DateField(null=True, blank=True)

    STATUS_CHOICES = [
        ('Paid', 'Paid'),
        ('Pending', 'Pending'),
        ('Overdue', 'Overdue'),
    ]
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')

    def __str__(self):
        return f"{self.student_name} - {self.month}"
