import React, { useState } from "react";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { toast } from "react-toastify";

// Fetch array buffer for background image with timeout
async function fetchArrayBuffer(url) {
  try {
    const controller = new AbortController();
    setTimeout(() => controller.abort(), 5000); // 5s timeout
    const response = await fetch(url, { mode: "cors", signal: controller.signal });
    if (!response.ok) throw new Error(`Failed to fetch ${url}`);
    return await response.arrayBuffer();
  } catch (error) {
    console.error(`Error fetching ${url}:`, error.message);
    throw error;
  }
}

// Validate image format (PNG or JPEG)
async function validateImageFormat(arrayBuffer) {
  const firstBytes = new Uint8Array(arrayBuffer.slice(0, 4));
  const isJpeg = firstBytes[0] === 0xFF && firstBytes[1] === 0xD8;
  const isPng = firstBytes[0] === 0x89 && firstBytes[1] === 0x50 && firstBytes[2] === 0x4E && firstBytes[3] === 0x47;
  if (!isJpeg && !isPng) throw new Error("Invalid image format. Only PNG and JPEG supported.");
  return isJpeg;
}

// Generate PDF with corrected margins, background, and overflow handling
async function generatePDFWithBackground(to, subject, bodyText) {
  try {
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage([595, 842]); // A4 size
    const { width, height } = page.getSize();
    const margin = 50;
    const topSpace = 144; // 2 inches

    // Use standard fonts
    const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    // Draw background first
    try {
      const imageArrayBuffer = await fetchArrayBuffer("/bg.png");
      const isJpeg = await validateImageFormat(imageArrayBuffer);
      const backgroundImage = isJpeg
        ? await pdfDoc.embedJpg(imageArrayBuffer)
        : await pdfDoc.embedPng(imageArrayBuffer);
      page.drawImage(backgroundImage, { x: 0, y: 0, width, height });
    } catch (error) {
      console.warn("Using fallback background:", error.message);
      page.drawRectangle({ x: 0, y: 0, width, height, color: rgb(1, 1, 1) }); // White fallback
    }

    // Compact headers on top-right
    const headers = [
      "Address: Office # 8, First Floor, Khyber III",
      "G-15 Markaz Islamabad, Pakistan",
      "Phone: 0316-7394390",
      `Date: ${new Date().toLocaleString("en-PK", { dateStyle: "full", timeZone: "Asia/Karachi" })}`,
    ];
    const maxWidth = 200;
    const headerStartY = height - margin;
    headers.forEach((line, i) => {
      page.drawText(line, {
        x: width - margin - maxWidth,
        y: headerStartY - (i * 20), // Increased spacing
        size: 10,
        
        font: fontRegular,
        color: rgb(0, 0, 0),
        maxWidth: maxWidth,
        
      });
    });

    // "To" field
    page.drawText(`To: ${to}`, {
      x: margin,
      y: height - topSpace - 20,
      size: 12,
      font: fontRegular,
      color: rgb(0, 0, 0),
    });

    // "Subject" field
    page.drawText(`Subject: ${subject}`, {
      x: margin,
      y: height - topSpace - 40,
      size: 12,
      font: fontRegular,
      color: rgb(0, 0, 0),
    });

    // Body text with bold parsing and overflow check
    const fontSize = 12;
    let yPosition = height - topSpace - 60;
    const lines = bodyText.split("\n");
    for (const line of lines) {
      if (yPosition < margin + 50) { // Reserve space for footer
        toast.warning("Text exceeds page; truncated.");
        break;
      }
      let xPosition = margin;
      const parts = line.split(/(\*[^*]+\*)/g);
      for (const part of parts) {
        if (part.startsWith("*") && part.endsWith("*")) {
          const text = part.slice(1, -1);
          const textWidth = fontBold.widthOfTextAtSize(text, fontSize);
          page.drawText(text, {
            x: xPosition,
            y: yPosition,
            size: fontSize,
            lineHeight: fontSize + 5, maxWidth: width - 2 * margin,
            font: fontBold,
            color: rgb(0, 0, 0),
          });
          xPosition += textWidth;
        } else {
          const textWidth = fontRegular.widthOfTextAtSize(part, fontSize);
          page.drawText(part, {
            x: xPosition,
            y: yPosition,
            size: fontSize,
            font: fontRegular,
            color: rgb(0, 0, 0),
            lineHeight: fontSize + 5, maxWidth: width - 2 * margin,
          });
          xPosition += textWidth;
        }
      }
      yPosition -= fontSize + 5;
    }

    // Regards
    if (yPosition >= margin + 50) {
      page.drawText("Regards: KoderKids", {
        x: margin,
        y: yPosition - 20,
        size: 12,
        font: fontRegular,
        color: rgb(0, 0, 0),
      });
    }

    // Footer centered
    const footerText = "This is a system generated report and doesn’t require signature.";
    const footerX = (width - fontRegular.widthOfTextAtSize(footerText, 10)) / 2;
    page.drawText(footerText, {
      x: footerX,
      y: margin,
      size: 10,
      font: fontRegular,
      color: rgb(0, 0, 0),
    });

    const pdfBytes = await pdfDoc.save();
    return new Blob([pdfBytes], { type: "application/pdf" });
  } catch (error) {
    console.error("Error generating PDF:", error.message);
    toast.error(`Failed to generate report: ${error.message}`);
    throw error;
  }
}

const CustomReport = () => {
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [bodyText, setBodyText] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleGenerateReport = async () => {
    if (!to || !subject || !bodyText.trim()) {
      setErrorMessage("Please enter To, Subject, and Body text.");
      toast.warning("All fields are required.");
      return;
    }
    if (to.length > 100 || subject.length > 100) {
      setErrorMessage("To and Subject must be under 100 characters.");
      toast.warning("Input too long.");
      return;
    }

    setErrorMessage("");
    setIsGenerating(true);

    try {
      const pdfBlob = await generatePDFWithBackground(to, subject, bodyText);
      const url = window.URL.createObjectURL(pdfBlob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `Custom_Report_${subject.replace(/\s+/g, "_")}.pdf`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast.success("Report generated successfully!");
    } catch (error) {
      setErrorMessage(`Failed to generate report: ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h2 className="text-2xl font-bold text-gray-700 mb-6">📝 Custom Report</h2>

      {errorMessage && (
        <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">{errorMessage}</div>
      )}

      <div className="flex flex-col gap-4 mb-6">
        <div className="flex flex-col">
          <label className="font-bold mb-1 text-gray-700" htmlFor="to">
            To:
          </label>
          <input
            id="to"
            type="text"
            className="p-2 border rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            placeholder="Enter recipient (e.g., Mr. Babar)"
            maxLength={100}
            aria-required="true"
          />
        </div>

        <div className="flex flex-col">
          <label className="font-bold mb-1 text-gray-700" htmlFor="subject">
            Subject:
          </label>
          <input
            id="subject"
            type="text"
            className="p-2 border rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Enter report subject"
            maxLength={100}
            aria-required="true"
          />
        </div>

        <div className="flex flex-col">
          <label className="font-bold mb-1 text-gray-700" htmlFor="bodyText">
            Body Text (use *bold* for formatting):
          </label>
          <textarea
            id="bodyText"
            className="p-2 border rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
            value={bodyText}
            onChange={(e) => setBodyText(e.target.value)}
            placeholder="Enter report content (e.g., *bold text*, new lines with Enter)"
            rows={6}
            aria-required="true"
          />
        </div>
      </div>

      <button
        onClick={handleGenerateReport}
        className={`bg-blue-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 ${
          isGenerating ? "opacity-75 cursor-not-allowed" : "hover:bg-blue-600"
        }`}
        disabled={isGenerating}
        aria-label={isGenerating ? "Generating report" : "Generate report"}
      >
        {isGenerating ? (
          <>
            <svg
              className="animate-spin h-5 w-5 mr-2 text-white"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              />
            </svg>
            Generating...
          </>
        ) : (
          <>📄 Generate Report</>
        )}
      </button>
    </div>
  );
};

export default CustomReport;