import axios from "axios";

// Base URL from environment variable
const API_URL = process.env.REACT_APP_API_URL;

// Function to get students with ngrok skip-header
export const getStudents = async () => {
    try {
        const response = await axios.get(`${API_URL}/api/students/`, {
            headers: {
                'ngrok-skip-browser-warning': 'true'
            }
        });
        return response.data; // Return JSON data
    } catch (error) {
        console.error("Error fetching students:", error);
        return [];
    }
};
