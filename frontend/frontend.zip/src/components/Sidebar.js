import React from "react";
import { Link } from "react-router-dom";

const Sidebar = () => {
    return (
        <aside className="w-64 h-screen bg-gray-900 text-white p-4 fixed left-0 top-0">
    <h2 className="text-lg font-bold mb-4">Navigation</h2>
    <ul>
        <li className="mb-2 p-2 hover:bg-gray-700 rounded">
            🏠 <Link to="/" className="ml-2">Home</Link>
        </li>
        <li className="mb-2 p-2 hover:bg-gray-700 rounded">
            📋 <Link to="/students" className="ml-2">Students</Link>
        </li>
        <li className="mb-2 p-2 hover:bg-gray-700 rounded">
            💰 <Link to="/fee" className="ml-2">Fee</Link>
        </li>
        <li className="mb-2 p-2 hover:bg-gray-700 rounded">
            🏫 <Link to="/schools" className="ml-2">Schools & Classes</Link>
        </li>
        <li className="mb-2 p-2 hover:bg-gray-700 rounded">
            📊 <Link to="/reports" className="ml-2">Reports & Analytics</Link>
        </li>
        <li className="mb-2 p-2 hover:bg-gray-700 rounded">
            ⚙️ <Link to="/settings" className="ml-2">Settings</Link>
        </li>
    </ul>
</aside>
    );
};

export default Sidebar;
