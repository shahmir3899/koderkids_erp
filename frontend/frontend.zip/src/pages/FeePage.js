import React, { useEffect, useState } from "react";
import axios from "axios";

function FeePage() {
    const [fees, setFees] = useState([]);
    const [schoolFilter, setSchoolFilter] = useState("");
    const [classFilter, setClassFilter] = useState("");
    const [monthFilter, setMonthFilter] = useState("");
    const [editingRow, setEditingRow] = useState(null);
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [modifiedFees, setModifiedFees] = useState({});

    const [filteredFees, setFilteredFees] = useState([]); // Stores only filtered results
    const [showResults, setShowResults] = useState(false); // Prevents auto-loading of data



    async function fetchFees() {
        try {
            const response = await axios.get(`${process.env.REACT_APP_API_URL}/api/fees/`);

            console.log("Fetched Fees Data:", response.data);
            setFees(response.data); // Store data but do not display immediately
        } catch (error) {
            console.error("Error fetching fees:", error);
        }
    }
    

    useEffect(() => {
        fetchFees();
    }, []);

    function handlePaidAmountChange(id, amount) {
        setFees(fees.map(fee => 
            fee.id === id ? { 
                ...fee, 
                paid_amount: amount, 
                balance_due: fee.total_fee - amount 
            } : fee
        ));
    }
    function handleTotalFeeChange(id, amount) {
        setFees(fees.map(fee => 
            fee.id === id ? { ...fee, total_fee: amount } : fee
        ));
    }
    function handleStatusChange(id, newStatus) {
        setFees(fees.map(fee => 
            fee.id === id ? { ...fee, status: newStatus } : fee
        ));
    }

    async function savePaidAmounts() {
        try {
            console.log("Sending updated fee data:", fees);
            const response = await axios.post(`${process.env.REACT_APP_API_URL}/api/fees/update/`, { fees });

            console.log("Server response:", response.data);
            alert("Payments updated successfully!");
        } catch (error) {
            console.error("Error updating payments:", error);
            alert("Failed to update payments!");
        }
    }

    async function createNewMonthRecords() {
        try {
            const response = await axios.post(`${process.env.REACT_APP_API_URL}/api/fees/create/`);

            alert(response.data.message);
            fetchFees();
        } catch (error) {
            console.error("Error creating new month records:", error);
            alert("Failed to create new month records.");
        }
    }

    // ✅ Table Styling
    const tableStyle = {
      width: "90%",
      borderCollapse: "collapse",
      marginTop: "7px",
      marginLeft: "auto",  // ✅ Center the table horizontally
      marginRight: "auto",
  };
  
    const thTdStyle = {
        border: "1px solid #ddd",
        padding: "2px",
        textAlign: "center",
    };

    const thStyle = {
        backgroundColor: "#007BFF",
        color: "white",
    };

    const trAlternate = {
        backgroundColor: "#f2f2f2",
    };

    // ✅ Button Styling
    const buttonStyle = {
        padding: "12px 20px",
        fontSize: "16px",
        backgroundColor: "#007BFF",
        color: "white",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer",
        fontWeight: "bold",
        transition: "0.3s",
    };

    const saveButtonStyle = {
        ...buttonStyle,
        backgroundColor: "#28a745",
    };

    const buttonHoverStyle = {
        backgroundColor: "#0056b3",
    };

    const saveButtonHoverStyle = {
        backgroundColor: "#218838",
    };

    // ✅ Filter Styling
    const filterContainer = {
        marginBottom: "15px",
        display: "flex",
        alignItems: "center",
        gap: "15px",
        flexWrap: "wrap",  // ✅ Allows filters to wrap if space is limited
    };

    const filterLabel = {
        fontWeight: "bold",
    };

    const filterSelect = {
        padding: "5px",
        borderRadius: "5px",
        border: "1px solid #ccc",
    };

    return (
        <div className="App" style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
            {/* Header */}
            <h1 style={{ color: "#2c3e50", marginBottom: "20px", textAlign: "center" }}>Fee Management</h1>
    
            {/* Filters Section */}
            <div style={{ ...filterContainer, marginBottom: "20px", display: "flex", alignItems: "center", gap: "15px", flexWrap: "wrap" }}>
                {/* School Filter */}
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                    <label style={{ ...filterLabel, color: "#34495e", fontWeight: "bold" }}>School: </label>
                    <select
                        value={schoolFilter}
                        onChange={(e) => setSchoolFilter(e.target.value)}
                        style={{ ...filterSelect, padding: "8px", borderRadius: "5px", border: "1px solid #bdc3c7", backgroundColor: "#ecf0f1", color: "#2c3e50" }}
                    >
                        <option value="">All Schools</option>
                        {Array.from(new Set(fees.map(fee => fee.school))).map((school, index) => (
                            <option key={index} value={school}>{school}</option>
                        ))}
                    </select>
                </div>
    
                {/* Class Filter */}
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                    <label style={{ ...filterLabel, color: "#34495e", fontWeight: "bold" }}>Class: </label>
                    <select
                        value={classFilter}
                        onChange={(e) => setClassFilter(e.target.value)}
                        style={{ ...filterSelect, padding: "8px", borderRadius: "5px", border: "1px solid #bdc3c7", backgroundColor: "#ecf0f1", color: "#2c3e50" }}
                    >
                        <option value="">All Classes</option>
                        {Array.from(new Set(fees.map(fee => fee.student_class)))
                        .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))  // ✅ Sorts classes
                        .map((student_class, index) => (
                            <option key={index} value={student_class}>{student_class}</option>
                    ))}
                    </select>
                </div>
    
                {/* Month Filter */}
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                    <label style={{ ...filterLabel, color: "#34495e", fontWeight: "bold" }}>Month: </label>
                    <select
                        value={monthFilter}
                        onChange={(e) => setMonthFilter(e.target.value)}
                        style={{ ...filterSelect, padding: "8px", borderRadius: "5px", border: "1px solid #bdc3c7", backgroundColor: "#ecf0f1", color: "#2c3e50" }}
                    >
                        <option value="">All Months</option>
                        {Array.from(new Set(fees.map(fee => fee.month))).map((month, index) => (
                            <option key={index} value={month}>{month}</option>
                        ))}
                    </select>
                </div>
            </div>
            <button 
    onClick={() => {
        const results = fees.filter(fee => 
            (schoolFilter === "" || fee.school === schoolFilter) &&
            (classFilter === "" || fee.student_class?.toString() === classFilter) &&
            (monthFilter === "" || fee.month === monthFilter)
        );
        setFilteredFees(results);
        setShowResults(true);
    }}
    style={{
        padding: "10px 20px",
        backgroundColor: "#007BFF",
        color: "white",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer",
        fontWeight: "bold"
    }}
>
    🔍 Search
</button>
            {/* Create New Month Button */}
            <button
                onClick={createNewMonthRecords}
                style={{
                    ...buttonStyle,
                    padding: "10px 20px",
                    borderRadius: "5px",
                    border: "none",
                    backgroundColor: "#3498db",
                    color: "#fff",
                    fontWeight: "bold",
                    cursor: "pointer",
                    transition: "background-color 0.3s ease",
                    marginBottom: "20px"
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = "#2980b9"}
                onMouseLeave={(e) => e.target.style.backgroundColor = "#3498db"}
            >
                ➕ Create New Month Record
            </button>
    
            {/* Fee Table */}
            <table style={{ ...tableStyle, width: "100%", borderCollapse: "collapse", marginBottom: "20px" }}>
                <thead>
                    <tr style={{ backgroundColor: "#3498db", color: "#fff" }}>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Student Name</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>School</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Class</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Month</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Monthly Fee</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Total Fee</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Paid Amount</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Balance Due</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Payment Date</th>
                        <th style={{ ...thTdStyle, ...thStyle, padding: "12px", textAlign: "left" }}>Status</th>
                    </tr>
                </thead>
                <tbody>
    {showResults && filteredFees.length > 0 ? (
        filteredFees.map((fee, index) => (
            <tr 
                key={fee.id} 
                style={{ ...(index % 2 === 0 ? { backgroundColor: "#f9f9f9" } : trAlternate), transition: "background-color 0.3s ease" }}
            >
                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>{fee.student_name}</td>
                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>{fee.school}</td>
                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>{fee.student_class}</td>
                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>{fee.month}</td>
                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>{fee.monthly_fee}</td>

                {/* Editable Total Fee Column */}
                <td>
                    {editingRow === fee.id ? (
                        <>
                            <input 
                                type="number" 
                                value={fee.total_fee} 
                                onChange={(e) => handleTotalFeeChange(fee.id, e.target.value)}
                                style={{ width: "80px", textAlign: "center" }}
                            />
                            <button 
                                onClick={() => setEditingRow(null)} 
                                style={{ marginLeft: "5px", padding: "3px 5px", fontSize: "12px", backgroundColor: "#28a745", color: "white", border: "none", cursor: "pointer", borderRadius: "3px" }}
                            >
                                ✅
                            </button>
                        </>
                    ) : (
                        <>
                            {fee.total_fee}
                            <button 
                                onClick={() => setEditingRow(fee.id)} 
                                style={{ marginLeft: "5px", padding: "3px 5px", fontSize: "12px", backgroundColor: "#007BFF", color: "white", border: "none", cursor: "pointer", borderRadius: "3px" }}
                            >
                                ✏️
                            </button>
                        </>
                    )}
                </td>

                {/* Editable Paid Amount Column */}
                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>
                    <input
                        type="number"
                        value={fee.paid_amount}
                        onChange={(e) => handlePaidAmountChange(fee.id, e.target.value)}
                        style={{ width: "80px", padding: "5px", borderRadius: "5px", border: "1px solid #bdc3c7", textAlign: "center" }}
                    />
                </td>

                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>{fee.balance_due}</td>
                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>{fee.payment_date || "N/A"}</td>

                {/* Editable Status Column */}
                <td style={{ ...thTdStyle, padding: "12px", textAlign: "left" }}>
                    <select
                        value={fee.status}
                        onChange={(e) => handleStatusChange(fee.id, e.target.value)}
                        style={{ padding: "5px", borderRadius: "5px", border: "1px solid #bdc3c7", backgroundColor: "#ecf0f1", color: "#2c3e50" }}
                    >
                        <option value="Pending">Pending</option>
                        <option value="Paid">Paid</option>
                        <option value="Overdue">Overdue</option>
                    </select>
                </td>

                {/* View Student Profile Button */}
                
            </tr>
        ))
    ) : (
        <tr>
            <td colSpan="11" style={{ textAlign: "center", padding: "12px", fontStyle: "italic", color: "#666" }}>
                No Data Available
            </td>
        </tr>
    )}
</tbody>

            </table>
    
            {/* Save Payments Button */}
            <button
                onClick={savePaidAmounts}
                style={{
                    ...saveButtonStyle,
                    padding: "10px 20px",
                    borderRadius: "5px",
                    border: "none",
                    backgroundColor: "#27ae60",
                    color: "#fff",
                    fontWeight: "bold",
                    cursor: "pointer",
                    transition: "background-color 0.3s ease"
                }}
                onMouseEnter={(e) => e.target.style.backgroundColor = "#219653"}
                onMouseLeave={(e) => e.target.style.backgroundColor = "#27ae60"}
            >
                💾 Save Payments
            </button>
        </div>
    );
}

export default FeePage;
