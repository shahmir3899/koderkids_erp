import React, { useEffect, useState } from "react";
import { getStudents } from "../api"; // Import API function
import "../App.css"; // Keep styling

function StudentsPage() {
    const [students, setStudents] = useState([]);
    const [selectedStudent, setSelectedStudent] = useState(null);
    const [searchTerm, setSearchTerm] = useState(""); // Search filter (Name & Reg Num)
    const [schoolFilter, setSchoolFilter] = useState(""); // School filter
    const [classFilter, setClassFilter] = useState(""); // Class filter

    useEffect(() => {
        async function fetchStudents() {
            const data = await getStudents();
            console.log("Fetched Students:", data);
            setStudents(data);
        }
        fetchStudents();
    }, []);

    // Get unique school and class names for filters
    const uniqueSchools = [...new Set(students.map(student => student.school))];
    const uniqueClasses = [...new Set(students.map(student => student.student_class))];

    // Function to filter students based on search, school, and class filters
    const [showResults, setShowResults] = useState(false);

const filteredStudents = students.filter((student) =>
    showResults &&
    (searchTerm === "" || 
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        student.reg_num.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (schoolFilter === "" || student.school === schoolFilter) &&
    (classFilter === "" || student.student_class === classFilter)
);


    return (
        <div className="App">
            <header className="App-header">
                <h1>Student Management</h1>

                {/* Search Input */}
                <input
                    type="text"
                    placeholder="Search by Name or Reg Num"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />

                {/* School Filter */}
                <select value={schoolFilter} onChange={(e) => setSchoolFilter(e.target.value)}>
                    <option value="">All Schools</option>
                    {uniqueSchools.map((school, index) => (
                        <option key={index} value={school}>{school}</option>
                    ))}
                </select>

                {/* Class Filter */}
                <select value={classFilter} onChange={(e) => setClassFilter(e.target.value)}>
                    <option value="">All Classes</option>
                    {uniqueClasses.map((cls, index) => (
                        <option key={index} value={cls}>{cls}</option>
                    ))}
                </select>
                <button 
    onClick={() => setShowResults(true)}
    style={{ padding: "10px", backgroundColor: "#007BFF", color: "white", border: "none", borderRadius: "5px", cursor: "pointer" }}
>
    🔍 Search
</button>
            </header>

            {/* Student Table */}
            <table className="student-table">
                <thead>
                    <tr>
                        <th>Reg Num</th>
                        <th>Name</th>
                        <th>School</th>
                        <th>Class</th>
                        <th>Monthly Fee</th>
                        <th>Phone</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredStudents.map((student) => (
                        <tr key={student.id} onClick={() => setSelectedStudent(student)} style={{ cursor: "pointer" }}>
                        <td>{student.reg_num}</td>
                        <td>{student.name}</td>
                        <td>{student.school}</td>
                        <td>{student.student_class}</td>
                        <td>{student.monthly_fee}</td>
                        <td>{student.phone}</td>
                        <td>
                            <button 
                                onClick={() => setSelectedStudent(student)}
                                style={{ padding: "5px 10px", backgroundColor: "#28a745", color: "white", border: "none", borderRadius: "5px", cursor: "pointer" }}
                            >
                                View Details
                            </button>
                        </td>
                    </tr>
                    
                    ))}
                </tbody>
            </table>
            {selectedStudent && (
    <div className="student-profile" style={{ marginTop: "20px", padding: "15px", border: "1px solid #ccc", borderRadius: "5px", backgroundColor: "#f8f9fa" }}>
        <h2 style={{ color: "#007BFF" }}>Student Profile</h2>
        <p><strong>Reg Num:</strong> {selectedStudent.reg_num}</p>
        <p><strong>Name:</strong> {selectedStudent.name}</p>
        <p><strong>School:</strong> {selectedStudent.school}</p>
        <p><strong>Class:</strong> {selectedStudent.student_class}</p>
        <p><strong>Monthly Fee:</strong> {selectedStudent.monthly_fee}</p>
        <p><strong>Phone:</strong> {selectedStudent.phone}</p>
        <button 
            onClick={() => setSelectedStudent(null)}
            style={{ marginTop: "10px", padding: "5px 10px", backgroundColor: "#dc3545", color: "white", border: "none", borderRadius: "5px", cursor: "pointer" }}
        >
            Close
        </button>
    </div>
)}
        </div>
    );
}

export default StudentsPage;
