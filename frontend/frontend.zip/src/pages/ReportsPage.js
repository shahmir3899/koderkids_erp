import React from "react";

function ReportsPage() {
    return (
        <div className="flex flex-col items-center p-6">
            <h1 className="text-2xl font-bold">Reports & Analytics</h1>
            <p>View analytics and generate reports here.</p>
        </div>
    );
}

export default ReportsPage;
